#!/bin/bash
# Furnace Terminal Emulator - Installation Script

set -e

echo "=========================================="
echo "Furnace Terminal Emulator - Installer"
echo "=========================================="
echo ""

# Check if running as root for system-wide install
if [ "$EUID" -eq 0 ]; then
    INSTALL_DIR="/usr/local/bin"
    DOC_DIR="/usr/local/share/doc/furnace"
    echo "Installing system-wide to $INSTALL_DIR"
else
    INSTALL_DIR="$HOME/.local/bin"
    DOC_DIR="$HOME/.local/share/doc/furnace"
    echo "Installing to user directory: $INSTALL_DIR"
    mkdir -p "$INSTALL_DIR"
fi

# Install binary
echo "Installing furnace binary..."
cp furnace "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/furnace"

# Install documentation
echo "Installing documentation..."
mkdir -p "$DOC_DIR"
cp README.md LICENSE "$DOC_DIR/" 2>/dev/null || true
cp config.example.lua "$DOC_DIR/" 2>/dev/null || true

echo ""
echo "✓ Installation complete!"
echo ""
echo "Furnace has been installed to: $INSTALL_DIR/furnace"
echo ""

# Check if directory is in PATH
if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
    echo "⚠ NOTE: $INSTALL_DIR is not in your PATH"
    echo ""
    echo "Add it to your PATH by adding this line to your ~/.bashrc or ~/.zshrc:"
    echo "  export PATH=\"$INSTALL_DIR:\$PATH\""
    echo ""
fi

echo "To run Furnace, type: furnace"
echo ""
